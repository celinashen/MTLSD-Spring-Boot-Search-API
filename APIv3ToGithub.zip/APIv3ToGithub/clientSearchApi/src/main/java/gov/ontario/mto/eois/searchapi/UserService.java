package gov.ontario.mto.eois.searchapi;

import java.util.List;

import gov.ontario.mto.eois.model.ClientSearchRequest;

public interface UserService {
    
    List<UserData> findAll();
    
    List<UserData> findBySearchCriteria(ClientSearchRequest body);

    
}