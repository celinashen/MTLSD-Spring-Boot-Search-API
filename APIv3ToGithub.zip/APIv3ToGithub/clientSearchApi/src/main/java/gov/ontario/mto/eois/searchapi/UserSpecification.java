package gov.ontario.mto.eois.searchapi;

import java.util.Date;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import gov.ontario.mto.eois.model.ClientSearchRequest;

@Service
public class UserSpecification implements UserService{

    @Autowired
    private UserDataRepository userDataRepository;


    @Override
    public List<UserData> findAll() {
        return userDataRepository.findAll(new Specification<UserData>() {
            @Override
            public Predicate toPredicate(Root<UserData> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                return null;
            }
        });
    }

    public List<UserData> findBySearchCriteria(ClientSearchRequest body){
        return userDataRepository.findAll(new Specification<UserData>() {
            @Override
            public Predicate toPredicate(Root<UserData> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {

                String firstName = body.getFirstName();
                String lastName = body.getLastName();
                String refNumber = body.getReferenceNumber();
                System.out.println(body.getReferenceNumber());
                LocalDate dateOfBirth = body.getDateOfBirth();
            //    Long concernRoleId = body.getConcernRoleId();
                String gender = body.getGender();

                List<Predicate> predicates = new ArrayList<>();

                if(firstName!=null) { 
                    predicates.add(criteriaBuilder.and(criteriaBuilder.like(root.get("firstName"), "%"+firstName+"%")));
                }
                if(lastName!=null) {
                    predicates.add(criteriaBuilder.and(criteriaBuilder.like(root.get("lastName"), "%"+lastName+"%")));
                } 
                if(refNumber!=null) {
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("refNumber"), refNumber)));
                }         
                if(dateOfBirth!=null) { 
                   predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("dateOfBirth"), dateOfBirth)));
                }     
            /**    if(concernRoleId!=null || !"".equals(concernRoleId)) {
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("concernRoleId"), concernRoleId)));
                }      */
                
                if(gender!=null){
                    predicates.add(criteriaBuilder.and(criteriaBuilder.equal(root.get("gender"), gender)));
                }      
            
                return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
            }
        });
    }
}
    


    


    