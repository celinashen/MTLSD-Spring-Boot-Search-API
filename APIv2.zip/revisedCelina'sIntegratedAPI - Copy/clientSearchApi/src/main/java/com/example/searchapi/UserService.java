package com.example.searchapi;

import java.util.List;

import io.swagger.model.ClientSearchRequest;

public interface UserService {
    
    List<UserData> findAll();
    
    List<UserData> findBySearchCriteria(ClientSearchRequest body);

    
}